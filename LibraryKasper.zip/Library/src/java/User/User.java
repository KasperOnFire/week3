package User;

public class User {

    private String uno;
    private String username;
    private String password;
    private String email;
}
